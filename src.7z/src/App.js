import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import TableView from './components/TableView';
import styled from 'styled-components';
import useFetchTableData from './hooks/useFetchTableData';

const AppContainer = styled.div`
  font-family: Arial, sans-serif;
`;

const MainLayout = styled.div`
  display: flex;
`;

const Content = styled.div`
  flex: 1;
  padding: 1rem;
`;

function App() {
  const [selectedItem, setSelectedItem] = useState(null);

  const handleSelect = (item) => {
    setSelectedItem(item);
  };

  return (
    <AppContainer>
      <Header />
      <MainLayout>
        <Sidebar onSelect={handleSelect} />
        <Content>
          {selectedItem !== null && (
            <>
                <TableView item={selectedItem} />
            </>
          )}
        </Content>
      </MainLayout>
    </AppContainer>
  );
}

export default App;
