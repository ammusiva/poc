import React, { useState } from 'react';
import { FaPlus } from 'react-icons/fa';
import ConfirmationModal from '../shared/ConfirmationModal';
import ItemModal from '../shared/ItemModal';
import TableLayout from './TableLayout';
import useFetchTableData from '../hooks/useFetchTableData';
import useModal from '../hooks/useModal';
import {
    TableContainer, LeftControls, RightControls, Header, FilterInput
} from '../styles/TableViewStyles';
const TableView = ({ item }) => {
    const { columns, data, loading, error, deleteRowById, handleItem } = useFetchTableData(item.id);
    const { isModalOpen, rowToDelete, openModal, closeModal, highlightedRowId,
        itemModalOpen, closeItemModal, handleModal } = useModal();
    const [filter, setFilter] = useState('');

    const filteredData = data.filter((row) =>
        Object.values(row).some((value) =>
            String(value).toLowerCase().includes(filter.toLowerCase())
        )
    );

    const handleAdd = () => {
        handleItem(itemModalOpen, data);
        closeItemModal();
    }
    const handleDelete = () => {
        if (rowToDelete !== null) {
            deleteRowById(rowToDelete);
        }
        closeModal();
    };

    const handleEdit = (row) => {
        handleModal("Update Item", "Update", row, true);
    }
    return (
        <>
            {isModalOpen && (
                <ConfirmationModal
                    message="Are you sure you want to delete this item?"
                    onConfirm={handleDelete}
                    onCancel={closeModal}
                />
            )}
            {itemModalOpen.isModalOpen && (
                <ItemModal
                    onCancel={closeItemModal}
                    onUpdate={handleAdd}
                    item={itemModalOpen}
                />
            )}
            <TableContainer>
                <h2>{item.name}</h2>
                {loading && <p>Loading...</p>}
                {error && <p>{error}</p>}
                {!loading && !error && (
                    <>
                        <Header>
                            <LeftControls>
                                <button onClick={() => handleModal()}> <FaPlus style={{ marginRight: '5px' }} />Add</button>
                            </LeftControls>

                            <RightControls>
                                <FilterInput
                                    type="text"
                                    placeholder="Filter..."
                                    value={filter}
                                    onChange={(e) => setFilter(e.target.value)}
                                />
                            </RightControls>
                        </Header>
                        <TableLayout
                            columns={columns}
                            filteredData={filteredData}
                            openModal={openModal}
                            handleEdit={handleEdit}
                            highlightedRowId={highlightedRowId}
                        />
                    </>
                )}
            </TableContainer>
        </>
    );
};

export default TableView;
