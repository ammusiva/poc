import React from 'react';
import styled from 'styled-components';

const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContainer = styled.div`
  background-color: #fff;
  padding: 2rem;
  border-radius: 8px;
  width: 300px;
  text-align: center;
`;

const ModalButton = styled.button`
  padding: 0.5rem 1rem;
  margin: 0.5rem;
  border: none;
  cursor: pointer;
  border-radius: 4px;
  background-color: ${(props) => (props.add ? '#e74c3c' : '#3498db')};
  color: white;

  &:hover {
    opacity: 0.8;
  }
`;

const ItemModal = ({ item, onUpdate, onCancel }) => {
    const message= item.message || "Add New Item";
    const  btnName= item.btnName || "Create";
  return (
    <ModalBackdrop>
      <ModalContainer>
        <h3>{message}</h3>
        <div>
          <ModalButton add onClick={onUpdate}>{btnName}</ModalButton>
          <ModalButton onClick={onCancel}>Cancel</ModalButton>
        </div>
      </ModalContainer>
    </ModalBackdrop>
  );
};

export default ItemModal;
