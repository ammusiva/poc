import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
const columns = [
    { "Header": "ID", "accessor": "id" },
    { "Header": "Name", "accessor": "name" },
    { "Header": "Status", "accessor": "status" }
  ];
  const items = [
    { "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },
    { "id": 3, "name": "Jane", "status": "Inactive" },
    { "id": 4, "name": "Jane", "status": "Inactive" },
    { "id": 5, "name": "Jane", "status": "Inactive" },
    { "id": 6, "name": "Jane", "status": "Inactive" },
    { "id": 7, "name": "Jane", "status": "Inactive" },
  ];
const useFetchTableData = (itemIndex) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  
  useEffect(() => {
    if (itemIndex === null) return;

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        // const response = await axios.get(`http://localhost:3001/data/${itemIndex}`);
        // setData(response.data.items || []);
        setData(items);
      } catch (err) {
        setError('Failed to fetch data');
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [itemIndex]);

  const deleteRowById = useCallback(
    async (rowId) => {
      try {
        // await axios.delete(`/api/tables/${id}/row/${rowId}`);
        setData((prevData) => prevData.filter((item) => item.id !== rowId));
      } catch (err) {
        console.error('Delete failed:', err);
      }
    },
    []
  );

  const handleItem = useCallback(
      async(item, data) => {
        try {
            if(item.isEdit) {
                const updatedData = data.map((ele) =>
                ele.id === item.data.id
                  ? { ...ele, name: "willson", status: "pending" }
                  : ele
              );
              
              setData(updatedData);
            } else {
            setData((prevData) => [...prevData, item]);
            }
          } catch (err) {
            console.error('add failed:', err);
          }
      }, []
  )

  return { data, loading, error, columns, deleteRowById, handleItem };
};

export default useFetchTableData;
