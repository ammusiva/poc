import { useEffect, useState } from 'react';
import axios from 'axios';
import { BASE_URL, GET_TABLES_LIST_URL } from '../constants/urls';
import { sort_sidebar_items } from '../utils/utils';

const useFetchSidebarItems = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchSidebarData = async () => {
      try {
          //epp-ggmap/
          const url = `${BASE_URL}${GET_TABLES_LIST_URL}`;
          const response = await axios.get(url);

          const temp = sort_sidebar_items(response.data.data);
          console.log("logger", response.data.data);
        setItems(temp);
      } catch (err) {
        setError(err);
      } finally {
        setLoading(false);
      }
    };

    fetchSidebarData();
  }, []);

  return { items, loading, error };
};

export default useFetchSidebarItems;
