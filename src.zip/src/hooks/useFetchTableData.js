import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { BASE_URL } from '../constants/urls';
import { getTableConfig } from '../utils/utils';

const useFetchTableData = ({table, group}) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [message, setMessage] = useState(null);
    const { columns, uniqueId } = getTableConfig(table);

    const resetMessages = () => {
      setTimeout(() => {
        setMessage('');
        setError('');
      }, 4000);
    }
    const fetchData = async (table) => {
        setLoading(true);
        setError(null);
        try {
          const url = `${BASE_URL}${group}/getAllRecords?tableName=${table}`;
            const response = await axios.get(url);
            console.log("logger", response);
          setData([...response.data, ...response.data, ...response.data, ...response.data, ...response.data, ...response.data]);
        } catch (err) {
          setError('Failed to fetch data');
        } finally {
          setLoading(false);
        }
      };
  useEffect(() => {
    if (table === null) return;
    fetchData(table);
  }, [table]);
useEffect(()=> {
console.log("logger for message", error);
}, [error])

  const deleteRowById = useCallback(
    async (rowId, obj) => {
      console.log("logger for ", rowId);
        try {
            const url = `${BASE_URL}${obj.group}/deleteRecord?tableName=${obj.table}&id=${rowId}`;
              const response = await axios.get(url);
              if(response.status == 201) {
                fetchData(table);
                setMessage(response.data.message);
              }
              else 
                setError('Failed to delete item');
          } catch (err) {
            setError('Failed to delete item');
          } finally {
            setLoading(false);
            resetMessages();
          }
    },
    []
  );

  const addRecord = useCallback(
      async(record, table, group) => {
        try {
            if(record.isEdit) {
               alert('Will be soon....')
            } else {
              try {
                const url = `${BASE_URL}${group}/addRecord?tableName=${table}`;
                  const response = await axios.post(url, record);
                  console.log("resposne for add item", response);
                  if(response.status == 200){
                     fetchData(table);
                    setMessage(response.data.message);
                  }
                  else 
                    setError('Failed to add record');
              } catch (err) {
                setError('Failed to add record');
              } finally {
                setLoading(false);
              }
            }
          } catch (err) {
            console.error('add failed:', err);
          }
      }, []
  )

  return { data, loading, error, message, columns, deleteRowById, uniqueId, addRecord };
};

export default useFetchTableData;
