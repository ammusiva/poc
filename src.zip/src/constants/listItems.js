// src/constants/listItems.js

export const listGroups = [
    {
      groupName: 'GGMAP',
      items: [
        {
          id: 1,
          name: 'GGMAP 1',
          columns: [
            { Header: 'ID', accessor: 'id' },
            { Header: 'Name', accessor: 'name' },
            { Header: 'Email', accessor: 'email' }
          ]
        },
        {
          id: 2,
          name: 'GGMAP 2',
          columns: [
            { Header: 'ID', accessor: 'id' },
            { Header: 'Title', accessor: 'title' },
            { Header: 'Price', accessor: 'price' }
          ]
        }
      ]
    },
    {
      groupName: 'EPP',
      items: [
        {
          id: 3,
          name: 'EPP 1',
          columns: [
            { Header: 'Order ID', accessor: 'orderId' },
            { Header: 'Customer', accessor: 'customer' },
            { Header: 'Status', accessor: 'status' }
          ]
        },
        {
          id: 4,
          name: 'EPP 2',
          columns: [
            { Header: 'Invoice #', accessor: 'invoiceNo' },
            { Header: 'Date', accessor: 'date' },
            { Header: 'Amount', accessor: 'amount' }
          ]
        }
      ]
    }
  ];
  