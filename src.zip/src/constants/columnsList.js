import { formatDateArrayToISO, formatTimestampToISO } from "../utils/utils"


export const COLUMN_LIST={"claimflow_rules": {"columns":[{ header: 'Rule Id', accessorKey: 'ruleId', 
 minSize: 50,
size: 50 },
{ header: (
    <>
      Submitter<br />
      Id
    </>
  ), accessorKey: 'submitterId',  minSize: 70,
          size: 70 },
{ header: (<>Claim <br/> Type</>), accessorKey: 'claimType',  minSize: 60,
          size: 60 },
{ header: 'Bill Type Code', accessorKey: 'billTypeCode',  minSize: 80,
          size: 80 },
{ header: 'Place of Service', accessorKey: 'placeOfService',  minSize: 80,
          size: 80 },
{ header: 'Group Only Indicator', accessorKey: 'groupOnlyIndicator',  minSize: 80,
          size: 80 },
{ header: 'Flow Rule', accessorKey: 'flowRule',  minSize: 50,
          size: 50 },
{ header: 'From Dos', accessorFn: (row) => formatDateArrayToISO(row.fromDos), id: 'fromDos',  minSize: 80,
          size: 80 },
{ header: 'TO Dos', accessorFn: (row) => formatDateArrayToISO(row.toDos),
  id: 'toDos', minSize: 80,
  size: 80},
{ header: 'Effective Date', accessorFn: (row) => formatDateArrayToISO(row.effectiveDate), id: 'effectiveDate',  minSize: 80,
          size: 80 },
{ header: 'Termination Date', accessorFn: (row) => formatDateArrayToISO(row.terminationDate), id: 'terminationDate',  minSize: 80,
          size: 80 },
{ header: 'Status', accessorKey: 'status',  minSize: 50,
          size: 50 },
{ header: 'Updated By', accessorKey: 'updatedBy',  minSize: 80,
          size: 80 },
{ header: 'Updated On', accessorFn: (row) => formatTimestampToISO(row.updatedOn), id: 'updatedOn',  minSize: 140,
          size: 140 },
{ header: 'Created On', accessorFn: (row) => formatTimestampToISO(row.creationDate), id:  'creationDate',  minSize: 140,
size: 140 }], "uniqueId": "ruleId"},

"payr_id_over_tbl": {"columns":[
{ header: 'Prov Id', accessorKey: 'provId',  minSize: 150,
          size: 180 },
{ header: 'Payer Id', accessorKey: 'payrId' },
{ header: 'Oved Payr Id', accessorKey: 'ovrdPayrId' },
{ header: 'faclId', accessorKey: 'faclId' },
{ header: 'Effective Date', accessorKey: 'effDt' },
{ header: 'Canceled Date', accessorKey: 'cancDt' },
{ header: 'Status', accessorKey: 'stsCd' },
{ header: 'Updated By', accessorKey: 'lstUpdateUserId' },
{ header: 'Updated On', accessorKey: 'lstUpdtDttm' }], "uniqueId": "provId"}
}

export const  TABLES_ADD_EDIT =[{
  key: 'payr_id_over_tbl',
  value: [{ label: 'Prov Id', name: 'provId' },
          { label: 'Oved Payr Id', name: 'payrId' },
          { label: 'Oved Payr Id', name: 'ovrdPayrId' },
          { label: 'faclId', name: 'faclId' },
          { label: 'Effective Date', name: 'effDt', type: 'date' },
          { label: 'Canceled Date', name: 'cancDt', type: 'date' },
          { label: 'Updated By', name: 'lstUpdateUserId' }]
  }, {
  key: 'abcd',
  value: []
  },]
