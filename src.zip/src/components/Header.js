import React from 'react';
import styled from 'styled-components';

const HeaderWrapper = styled.div`
background: #007bff;
color: white;
padding: 1rem;
font-size: 1.2rem;

@media (max-width: 768px) {
  padding: 0.75rem;
  font-size: 1rem;
}
`;

const Header = () => {
  return <HeaderWrapper>My Application</HeaderWrapper>;
};

export default Header;
