import { useState } from 'react';

const itemObj = {
    isModalOpen: false,
    isEdit: false,
    message:"",
    data:{},
    btnName: "",
}
const useModal = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [rowToDelete, setRowToDelete] = useState(null);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [itemModalOpen, setItemModalOpen] = useState(itemObj);


  const handleModal = (message="Add", btnName="Create", data={}, isEdit=false) => {
      console.log("messageee", message, btnName);
      console.log("logger for highligh", data);
    setItemModalOpen(prev => ({
        ...prev,
        isModalOpen: true,
        btnName,
        message,
        data,
        isEdit
      }));
  }

  const closeItemModal = () => {
      console.log("logg");
    setItemModalOpen(itemObj);
  }

  const openModal = (rowId) => {
    setRowToDelete(rowId);
    setSelectedRowId(rowId);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setRowToDelete(null); 
  };

  return {
    isModalOpen,
    rowToDelete,
    itemModalOpen,
    handleModal,
    closeItemModal,
    openModal,
    closeModal,
    selectedRowId
  };
};

export default useModal;
