import { COLUMN_LIST } from "../constants/columnsList";

export const getTableConfig = (tableName) => {
    const tableConfig = COLUMN_LIST[tableName];
    if (!tableConfig) {
      return { columns: [], uniqueId: null };
    }
    return {
      columns: tableConfig.columns,
      uniqueId: tableConfig.uniqueId,
    };
  };
  export const formatDateArrayToISO = (dateArray) => {
    if (!Array.isArray(dateArray)) return '';
    const [year, month, day] = dateArray;
    if (!year || !month || !day) return '';
    const date = new Date(year, month - 1, day);
    return date.toISOString().split('T')[0];
  };

  export const formatTimestampToISO = (value) => {
    if (!value) return '';
    const normalized = String(value).length > 13
      ? Math.floor(value / Math.pow(10, String(value).length - 13))
      : Number(value);
    const date = new Date(normalized);
  
    if (isNaN(date.getTime())) return '';
  
    const pad = (n) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
           `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };

  export const sort_sidebar_items = (inputData) => {
    return Object.keys(inputData)
    .sort()
    .reduce((acc, key) => {
        acc[key] = inputData[key].slice().sort();
        return acc;
    }, {});
  }

  export const formatDateArray = ([year, month, day]) => {
    const mm = String(month + 1).padStart(2, '0'); // months are 0-indexed
    const dd = String(day).padStart(2, '0');
    return `${year}-${mm}-${dd}`;
  };
  