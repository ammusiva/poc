import React, { useState } from 'react';
import { MaterialReactTable } from 'material-react-table';
import { Box, Button, TextField, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
const Grid = ({ data, columns, onSearch, handleModal, uniqueId, selectedRowId, error, message }) => {
    const [searchValue, setSearchValue] = useState('');

    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchValue(value);
        onSearch(value);
    };
    if (!uniqueId) {
        return (
          <Box sx={{ padding: 2, textAlign: 'center' }}>
            <Typography variant="h6" color="text.secondary">
              No table defined
            </Typography>
          </Box>
        );
      }
    return (
        
        <MaterialReactTable
            columns={columns}
            data={data}
            enableFullScreenToggle={false}
            enableDensityToggle={false}
            enableHiding={false}
            enableSorting={false}
            enableColumnFilters={false}
            enableGlobalFilter={false}
            enableColumnActions={false}
            enableColumnResizing={false}
            layoutMode="grid"
            renderTopToolbarCustomActions={() => (
                <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                    width="100%"
                    padding="8px"
                    gap={2}
                >
                    <Button
                        variant="contained"
                        startIcon={<AddIcon />}
                        onClick={handleModal}
                    >
                        Add
                    </Button>
                    {message && (
            <Typography
                variant="body2"
                color={'success'}
                sx={{ whiteSpace: 'nowrap' }}
            >
                {message}
            </Typography>
        )}
        {error && (
            <Typography
                variant="body2"
                color={'error'}
                sx={{ whiteSpace: 'nowrap' }}
            >
                {error}
            </Typography>
        )}
                    <TextField
                        size="small"
                        placeholder="Search..."
                        value={searchValue}
                        onChange={handleSearchChange}
                        sx={{ width: '300px' }}
                    />
                </Box>
            )}
            enablePinning
            enableColumnOrdering={false}
            muiTableBodyCellProps={{
                sx: {
                    border: '1px solid rgba(224, 224, 224, 1)',
                    // whiteSpace: 'nowrap',
                },
            }}
            muiTableHeadCellProps={{
                sx: {
                    border: '1px solid rgba(224, 224, 224, 1)',
                    backgroundColor: '#f5f5f5',
                    whiteSpace: 'normal !important', // allow wrapping
                    wordWrap: 'break-word', // break long words
                    textAlign: 'center',
                    minHeight: 0,
                    height: 'auto',
                },
            }}
            muiTableHeadProps={{
                sx: {
                    border: '1px solid rgba(224, 224, 224, 1)',
                    backgroundColor: '#f5f5f5',
                    whiteSpace: 'normal !important',
                    
                },
            }}
            muiTableBodyRowProps={({ row }) => ({
                sx: {
                    minHeight: 0,
                    height: 'auto',
                    overflowX: 'unset',
                    backgroundColor:
      row.original[uniqueId] === selectedRowId ? 'rgba(25, 118, 210, 0.1)' : 'transparent',
                },
            })}
            muiTablePaperProps={{
                sx: {
                    border: '1px solid #ccc',
                    overflowX: 'unset',
                    marginTop: 0,
                },
            }}
            muiTableContainerProps={{
                sx: {
                    overflowX: 'auto',
                    maxHeight: 'unset', maxWidth: '100%',
                },
            }}
        />
    );
};

export default Grid;
