import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { BASE_URL } from '../constants/urls';
import { getTableConfig } from '../utils/utils';

const useFetchTableData = ({table, group}) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [message, setMessage] = useState(null);
    const { columns, uniqueId } = getTableConfig(table);

    const resetMessages = () => {
      setTimeout(() => {
        setMessage('');
        setError('');
      }, 4000);
    }
    const fetchData = async (table) => {
        setLoading(true);
        setError(null);
        try {
          const url = `${BASE_URL}${group}/getAllRecords?tableName=${table}`;
            const response = await axios.get(url);
            console.log("logger", response);
          setData([...response.data, ...response.data, ...response.data, ...response.data, ...response.data, ...response.data]);
        } catch (err) {
          setError('Failed to fetch data');
        } finally {
          setLoading(false);
        }
      };
  useEffect(() => {
    if (table === null) return;
    fetchData(table);
  }, [table]);

  const deleteRowById = useCallback(
    async (rowId, obj) => {
        try {
            const url = `${BASE_URL}${obj.group}/deleteRecord?tableName=${obj.table}&id=${rowId}`;
              const response = await axios.get(url);
              console.log("resposne for delete item", response);
              fetchData(table);
              if(response.status == 200)
                setMessage('Selected item deleted successfully.');
              else 
                setError('Failed to delete item');
          } catch (err) {
            setError('Failed to delete item');
          } finally {
            setLoading(false);
            resetMessages();
          }
    },
    []
  );

  const handleItem = useCallback(
      async(item, data) => {
        try {
            if(item.isEdit) {
                const updatedData = data.map((ele) =>
                ele.id === item.data.id
                  ? { ...ele, name: "willson", status: "pending" }
                  : ele
              );
              
              setData(updatedData);
            } else {
            setData((prevData) => [...prevData, item]);
            }
          } catch (err) {
            console.error('add failed:', err);
          }
      }, []
  )

  return { data, loading, error, message, columns, deleteRowById, handleItem,uniqueId };
};

export default useFetchTableData;
