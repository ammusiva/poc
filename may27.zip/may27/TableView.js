import React, { useState, useMemo } from 'react';
import { FaEdit, FaTrash } from 'react-icons/fa';
import ConfirmationModal from '../shared/ConfirmationModal';
import ItemModal from '../shared/ItemModal';
import Grid from './Grid';
import useFetchTableData from '../hooks/useFetchTableData';
import useModal from '../hooks/useModal';
import {
    TableContainer, TitleSpan
} from '../styles/TableViewStyles';
import useToast from '../hooks/useToast';
const TableView = ({ obj }) => {
    const { columns: baseColumns, data, loading, error, message, deleteRowById, handleItem, uniqueId } = useFetchTableData(obj);
    const { isModalOpen, rowToDelete, openModal, closeModal,
        itemModalOpen, closeItemModal, handleModal, selectedRowId } = useModal();
    const { toast, showToast, closeToast } = useToast();
    const [filter, setFilter] = useState('');

    const filteredData = data?.filter((row) =>
        Object.values(row).some((value) =>
            String(value).toLowerCase().includes(filter.toLowerCase())
        )
    );
    const handleAdd = () => {
        handleItem(itemModalOpen, data);
    }
    const handleDelete = async () => {
        if (rowToDelete !== null) {
            await deleteRowById(rowToDelete, obj);
            console.log("error", error, message);
        }
        closeModal();
    };

    const onEdit = (row) => {
        console.log("row data", row);
        handleModal("Update Item", "Update", row, true);
    }
    const columns_list = useMemo(() => [
        ...baseColumns.map(col => ({
          ...col,
          headerProps: {
            sx: {
              whiteSpace: 'normal',
              textOverflow: 'unset',
              overflow: 'visible',
              wordWrap: 'break-word',
              maxWidth: '150px',
            },
          },
        })),
        {
          header: 'Actions',
          id: 'actions',
          size: 50,
          minSize: 50,
          Cell: ({ row }) => (
            <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center' }}>
              <FaEdit
                style={{ cursor: 'pointer', color: '#1976d2' }}
                onClick={() => onEdit(row.original)}
              />
              <FaTrash
                style={{ cursor: 'pointer', color: '#d32f2f' }}
                onClick={() => openModal(row.original[uniqueId])}
              />
            </div>
          ),
          enableSorting: false,
          enableColumnFilter: false,
        },
      ], [baseColumns, onEdit, openModal, uniqueId]);

    
    return (
        <>
            {isModalOpen && (
                <ConfirmationModal
                    message="Are you sure you want to delete this item?"
                    onConfirm={handleDelete}
                    onCancel={closeModal}
                />
            )}
            {itemModalOpen.isModalOpen && (
                <ItemModal
                    onCancel={closeItemModal}
                    onUpdate={handleAdd}
                    item={itemModalOpen}
                />
            )}
            <TableContainer>
                <TitleSpan>{obj?.table}</TitleSpan>
                {loading && <p>Loading...</p>}
                {error && <p>{error}</p>}
                {!loading && !error && (
                    <>
                        <div style={{ overflowX: 'auto', width: '100%' }}>
                        <Grid
                            data={filteredData}
                            columns={columns_list}
                            onSearch={setFilter}
                            handleModal={handleModal}
                            uniqueId= {uniqueId}
                            selectedRowId={selectedRowId}
                            error={error}
                            message = {message}
                        />
                        </div>
                    </>
                )}
            </TableContainer>
        </>
    );
};

export default TableView;
