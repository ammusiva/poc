import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { BASE_URL } from '../constants/urls';
import { getTableConfig } from '../utils/utils';

const useFetchTableData = ({table, group}) => {
  console.log("loggerrrr", table, group);
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { columns, uniqueId } = getTableConfig(table);
    const fetchData = async (table) => {
        setLoading(true);
        setError(null);
        try {
          const url = `${BASE_URL}${group}/getAllRecords?tableName=${table}`;
            const response = await axios.get(url);
            console.log("logger", response);
          setData(response.data);
        } catch (err) {
          setError('Failed to fetch data');
        } finally {
          setLoading(false);
        }
      };
  useEffect(() => {
    if (table === null) return;
    fetchData(table);
  }, [table]);

  const deleteRowById = useCallback(
    async (rowId, table) => {
        try {
            const url = `${BASE_URL}deleteRecord?tableName=${table}&id=${rowId}`;
              const response = await axios.get(url);
              fetchData(table);
          } catch (err) {
            setError('Failed to fetch data');
          } finally {
            setLoading(false);
          }
    },
    []
  );

  const handleItem = useCallback(
      async(item, data) => {
        try {
            if(item.isEdit) {
                const updatedData = data.map((ele) =>
                ele.id === item.data.id
                  ? { ...ele, name: "willson", status: "pending" }
                  : ele
              );
              
              setData(updatedData);
            } else {
            setData((prevData) => [...prevData, item]);
            }
          } catch (err) {
            console.error('add failed:', err);
          }
      }, []
  )

  return { data, loading, error, columns, deleteRowById, handleItem,uniqueId };
};

export default useFetchTableData;
