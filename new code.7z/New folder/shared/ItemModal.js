import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import CloseIcon from '@mui/icons-material/Close';

const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContainer = styled.div`
  background-color: #fff;
  padding: 2rem;
  border-radius: 8px;
  width: 500px;
  max-height: 90vh;
  overflow-y: auto;
`;
const FormContainer = styled.form`
  display: flex;
  flex-direction: column;
  gap: 1rem;
`;

const InputGroup = styled.div`
  display: flex;
  flex-direction: column;
`;

const Label = styled.label`
  font-weight: 600;
  margin-bottom: 0.25rem;
`;

const Input = styled.input`
  padding: 0.5rem;
  font-size: 1rem;
  border: 1px solid ${({ error }) => (error ? '#d32f2f' : '#ccc')};
  border-radius: 4px;
`;

const Select = styled.select`
  padding: 0.5rem;
  font-size: 1rem;
  border: 1px solid ${({ error }) => (error ? '#d32f2f' : '#ccc')};
  border-radius: 4px;
`;

const ErrorText = styled.span`
  color: #d32f2f;
  font-size: 0.85rem;
`;


const ButtonRow = styled.div`
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  margin-top: 1rem;
`;

const SubmitButton = styled.button`
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  background-color: #1976d2;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 4px;
`;

const CancelButton = styled.button`
  padding: 0.75rem 1.5rem;
  font-size: 1rem;
  background-color: #9e9e9e;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 4px;
`;

const CloseIconButton = styled.button`
  position: absolute;
  top: 12px;
  right: 12px;
  background: transparent;
  border: none;
  cursor: pointer;
`;



const ItemModal = (item, closeItemModal) => {
        console.log("logger for modal", item);
        const data= item.data;
    const [formData, setFormData] = useState({
        ruleId: '',
        submitterId: '',
        claimType: '',
        billTypeCode: '',
        placeOfService: '',
        groupOnlyIndicator: '',
        flowRule: '',
        fromDos: '',
        toDos: '',
        effectiveDate: '',
        terminationDate: '',
        status: '',
        updatedBy: '',
        ...data, 
      });
    
      const [errors, setErrors] = useState({});
      
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
        setErrors((prev) => ({ ...prev, [name]: '' }));
      };
    
      const handleSubmit = (e) => {
        e.preventDefault();
        const newErrors = {};
    
        Object.keys(formData).forEach((key) => {
          if (!formData[key]) {
            newErrors[key] = 'This field is required';
          }
        });
    
        if (Object.keys(newErrors).length > 0) {
          setErrors(newErrors);
          return;
        }
    
        console.log("logger for ",formData);
      };

    return (
        <ModalBackdrop>
            <ModalContainer>
            <CloseIconButton onClick={closeItemModal}>
          <CloseIcon />
        </CloseIconButton>
                <FormContainer onSubmit={handleSubmit}>
                    {[
                        { label: 'Rule Id', name: 'ruleId' },
                        { label: 'Submitter Id', name: 'submitterId' },
                        { label: 'Claim Type', name: 'claimType' },
                        { label: 'Bill Type Code', name: 'billTypeCode' },
                        { label: 'Place of Service', name: 'placeOfService' },
                        { label: 'Group Only Indicator', name: 'groupOnlyIndicator', type: 'select', options: ['Y', 'N'] },
                        { label: 'Flow Rule', name: 'flowRule' },
                        { label: 'From Dos', name: 'fromDos', type: 'date' },
                        { label: 'TO Dos', name: 'toDos', type: 'date' },
                        { label: 'Effective Date', name: 'effectiveDate', type: 'date' },
                        { label: 'Termination Date', name: 'terminationDate', type: 'date' },
                        { label: 'Status', name: 'status', type: 'select', options: ['Active', 'Inactive'] },
                        { label: 'Updated By', name: 'updatedBy' },
                    ].map(({ label, name, type = 'text', options }) => (
                        <InputGroup key={name}>
                            <Label htmlFor={name}>{label}</Label>
                            {type === 'select' ? (
                                <Select name={name} value={formData[name] || ''} onChange={handleChange} error={errors[name]}>
                                    <option value="">--Select--</option>
                                    {options.map((opt) => (
                                        <option key={opt} value={opt}>{opt}</option>
                                    ))}
                                </Select>
                            ) : (
                                <Input type={type} name={name} value={formData[name] || ''} onChange={handleChange} error={errors[name]}/>
                            )}
                        </InputGroup>
                    ))}
                     <ButtonRow>
            <CancelButton type="button" onClick={closeItemModal}>Cancel</CancelButton>
            <SubmitButton type="submit">Submit</SubmitButton>
          </ButtonRow>
                </FormContainer>
            </ModalContainer>
        </ModalBackdrop>
    );
};

export default ItemModal;
