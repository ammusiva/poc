import React, { useState } from 'react';
import { MaterialReactTable } from 'material-react-table';
import { Box, Button, TextField, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
const Grid = ({ data, columns, onSearch, handleModal, uniqueId }) => {
    const [searchValue, setSearchValue] = useState('');

    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchValue(value);
        onSearch(value);
    };
    if (!uniqueId) {
        return (
          <Box sx={{ padding: 2, textAlign: 'center' }}>
            <Typography variant="h6" color="text.secondary">
              No table defined
            </Typography>
          </Box>
        );
      }
    return (
        
        <MaterialReactTable
            columns={columns}
            data={data}
            enableFullScreenToggle={false}
            enableDensityToggle={false}
            enableHiding={false}
            enableSorting={false}
            enableColumnFilters={false}
            enableGlobalFilter={false}
            enableColumnActions={false}
            enableColumnResizing={false}
            layoutMode="grid"
            renderTopToolbarCustomActions={() => (
                <Box
                    display="flex"
                    justifyContent="space-between"
                    alignItems="center"
                    width="100%"
                    padding="8px"
                    gap={2}
                >
                    <Button
                        variant="contained"
                        startIcon={<AddIcon />}
                        onClick={handleModal}
                    >
                        Add
                    </Button>
                    <TextField
                        size="small"
                        placeholder="Search..."
                        value={searchValue}
                        onChange={handleSearchChange}
                        sx={{ width: '300px' }}
                    />
                </Box>
            )}
            enablePinning
            enableColumnOrdering={false}
            muiTableBodyCellProps={{
                sx: {
                    border: '1px solid rgba(224, 224, 224, 1)',
                    whiteSpace: 'nowrap',
                },
            }}
            muiTableHeadCellProps={{
                sx: {
                    border: '1px solid rgba(224, 224, 224, 1)',
                    backgroundColor: '#f5f5f5',
                    whiteSpace: 'nowrap',
                    minHeight: 0,
                    height: 'auto',
                    paddingY: '4px',
                },
            }}
            muiTableHeadProps={{
                sx: {
                    minHeight: 0,
                    height: 'auto',
                },
            }}
            muiTableBodyRowProps={({ row }) => ({
                sx: {
                    minHeight: 0,
                    height: 'auto',
                    overflowX: 'unset',
                },
            })}
            muiTablePaperProps={{
                sx: {
                    border: '1px solid #ccc',
                    overflowX: 'unset',
                    marginTop: 0,
                },
            }}
            muiTableContainerProps={{
                sx: {
                    overflowX: 'auto',
                    maxHeight: 'unset', maxWidth: '100%',
                },
            }}
        />
    );
};

export default Grid;
