import React, { useState } from 'react';
import styled from 'styled-components';

const SidebarWrapper = styled.div`
width: 250px;
overflow-y: auto;
background: #f5f5f5;

@media (max-width: 768px) {
  width: 100%;
  height: auto;
}
`;

const SidebarItem = styled.div`
  margin: 0.25rem 0;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 4px;
  margin-left: 1rem;
  &.active {
    background-color: #007bff;
    color: white;
    font-weight: bold;
  }
  &:hover {
    background: #ddd;
  }
`;

export const GroupTitle = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  padding: 0.5rem;
  background-color: #f5f5f5;
  font-weight: bold;
  color: #333;

  .toggle-icon {
    font-size: 1.2rem;
    margin-left: 1rem;
  }
`;


const Sidebar = ({ onSelect, data, selectedItem }) => {
    const listKeys = Object.keys(data);

    const toggleGroup = (group) => {
        setExpandedGroups((prev) => ({
          ...prev,
          [group]: !prev[group],
        }));
      };
      const [expandedGroups, setExpandedGroups] = useState({});
  return (
    <SidebarWrapper>
      {listKeys?.map(item => (
        <div key={item}>
          <GroupTitle onClick={() => toggleGroup(item)}>
              {expandedGroups[item] ? '− ' : '+ '}
              {item}
              </GroupTitle>
          {expandedGroups[item] && data[item]?.map(tbl => (
            <SidebarItem
              key={tbl}
              className={selectedItem === tbl ? 'active' : ''}
              onClick={() => onSelect(tbl, item)}
            >
              {tbl}
            </SidebarItem>
          ))}
        </div>
      ))}
    </SidebarWrapper>
  );
};

export default Sidebar;
