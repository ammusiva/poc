import { COLUMN_LIST } from "../constants/columnsList";

export const getTableConfig = (tableName) => {
    const tableConfig = COLUMN_LIST[tableName];
    if (!tableConfig) {
      return { columns: [], uniqueId: null };
    }
    return {
      columns: tableConfig.columns,
      uniqueId: tableConfig.uniqueId,
    };
  };
  export const formatDateArrayToISO = (dateArray) => {
    if (!Array.isArray(dateArray)) return '';
    const [year, month, day] = dateArray;
    if (!year || !month || !day) return '';
    const date = new Date(year, month - 1, day); // JS months are 0-based
    return date.toISOString().split('T')[0]; // 'YYYY-MM-DD'
  };

  export const formatTimestampToISO = (value) => {
    if (!value) return '';
    const normalized = String(value).length > 13
      ? Math.floor(value / Math.pow(10, String(value).length - 13))
      : Number(value);
    const date = new Date(normalized);
  
    if (isNaN(date.getTime())) return '';
  
    const pad = (n) => String(n).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ` +
           `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
  };
  