import { formatDateArrayToISO, formatTimestampToISO } from "../utils/utils"


export const COLUMN_LIST={"claimflow_rules": {"columns":[{ header: 'Rule Id', accessorKey: 'ruleId' },
{ header: 'Submitter Id', accessorKey: 'submitterId' },
{ header: 'Claim Type', accessorKey: 'claimType' },
{ header: 'Bill Type Code', accessorKey: 'billTypeCode' },
{ header: 'Place of Service', accessorKey: 'placeOfService' },
{ header: 'Group Only Indicator', accessorKey: 'groupOnlyIndicator' },
{ header: 'Flow Rule', accessorKey: 'flowRule' },
{ header: 'From Dos', accessorFn: (row) => formatDateArrayToISO(row.fromDos), id: 'fromDos' },
{ header: 'TO Dos', accessorFn: (row) => formatDateArrayToISO(row.toDos),
  id: 'toDos', },
{ header: 'Effective Date', accessorFn: (row) => formatDateArrayToISO(row.effectiveDate), id: 'effectiveDate' },
{ header: 'Termination Date', accessorFn: (row) => formatDateArrayToISO(row.terminationDate), id: 'terminationDate' },
{ header: 'Status', accessorKey: 'status' },
{ header: 'Updated By', accessorKey: 'updatedBy' },
{ header: 'Updated On', accessorFn: (row) => formatTimestampToISO(row.updatedOn), id: 'updatedOn' },
{ header: 'Created On', accessorFn: (row) => formatTimestampToISO(row.creationDate), id:  'creationDate' }], "uniqueId": "ruleId"},

"payr_id_over_tbl": {"columns":[
{ header: 'Prov Id', accessorKey: 'provId' },
{ header: 'Payer Id', accessorKey: 'payrId' },
{ header: 'Oved Payr Id', accessorKey: 'ovrdPayrId' },
{ header: 'faclId', accessorKey: 'faclId' },
{ header: 'Effective Date', accessorKey: 'effDt' },
{ header: 'Canceled Date', accessorKey: 'cancDt' },
{ header: 'Status', accessorKey: 'stsCd' },
{ header: 'Updated By', accessorKey: 'lstUpdateUserId' },
{ header: 'Updated On', accessorKey: 'lstUpdtDttm' }], "uniqueId": "provId"}

}