import styled from 'styled-components';
export const TableContainer = styled.div`
  background-color: white;
  border-radius: 8px;
  width: 98%;
  overflow-x: auto;
`;
export const TitleSpan = styled.span`
font-weight: 800;
font-size: 24px;
`;
