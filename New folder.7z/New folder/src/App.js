import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import TableView from './components/TableView';
import styled from 'styled-components';
import useFetchTableData from './hooks/useFetchTableData';
import useFetchSidebarItems from './hooks/useFetchSidebarItems';

const AppContainer = styled.div`
  font-family: Arial, sans-serif;
`;

const MainLayout = styled.div`
  display: flex;
`;

const Content = styled.div`
  flex: 1;
  padding: 1rem;
`;
function App() {
  const [selectedItem, setSelectedItem] = useState(null);
  const { items, loading, error } = useFetchSidebarItems();
  const handleSelect = (item) => {
    setSelectedItem(item);
  };

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error loading while listing tables</p>;
  
  return (
    <AppContainer>
      <Header />
      <MainLayout>
        <Sidebar onSelect={handleSelect} data={items} />
        <Content>
          {selectedItem !== null && (
            <>
                <TableView item={selectedItem} />
            </>
          )}
        </Content>
      </MainLayout>
    </AppContainer>
  );
}

export default App;
