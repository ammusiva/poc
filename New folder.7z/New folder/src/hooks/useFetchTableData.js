import { useEffect, useState, useCallback } from 'react';
import axios from 'axios';
import { BASE_URL } from '../constants/urls';
import { COLUMN_LIST } from '../constants/columnsList';

const useFetchTableData = (item) => {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const { columns, uniqueId } = COLUMN_LIST[item];
    const fetchData = async (item) => {
        setLoading(true);
        setError(null);
        try {
          const url = `${BASE_URL}getAllRecords?tableName=${item}`;
            const response = await axios.get(url);
            console.log("logger", response);
          setData(response.data);
        } catch (err) {
          setError('Failed to fetch data');
        } finally {
          setLoading(false);
        }
      };
  useEffect(() => {
    if (item === null) return;
    fetchData(item);
  }, [item]);

  const deleteRowById = useCallback(
    async (rowId, tableName) => {
        try {
            const url = `${BASE_URL}deleteRecord?tableName=${tableName}&id=${rowId}`;
              const response = await axios.get(url);
              fetchData(item);
          } catch (err) {
            setError('Failed to fetch data');
          } finally {
            setLoading(false);
          }
    },
    []
  );

  const handleItem = useCallback(
      async(item, data) => {
        try {
            if(item.isEdit) {
                const updatedData = data.map((ele) =>
                ele.id === item.data.id
                  ? { ...ele, name: "willson", status: "pending" }
                  : ele
              );
              
              setData(updatedData);
            } else {
            setData((prevData) => [...prevData, item]);
            }
          } catch (err) {
            console.error('add failed:', err);
          }
      }, []
  )

  return { data, loading, error, columns, deleteRowById, handleItem,uniqueId };
};

export default useFetchTableData;
