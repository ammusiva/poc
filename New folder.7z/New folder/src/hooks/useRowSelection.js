// hooks/useRowSelection.js
import { useState } from 'react';

const useRowSelection = (data = [], setData, idKey = 'id') => {
  const [selectedRows, setSelectedRows] = useState([]);

  const isSelected = (id) => selectedRows.includes(id);

  const toggleSelectRow = (id) => {
    setSelectedRows((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectAll = () => {
    const allIds = data.map((item) => item[idKey]);
    setSelectedRows(allIds);
  };

  const deselectAll = () => setSelectedRows([]);

  const toggleSelectAll = () => {
    if (selectedRows.length === data.length) {
      deselectAll();
    } else {
      selectAll();
    }
  };

  const bulkDelete = (setData) => {
    const confirmDelete = window.confirm(`Delete ${selectedRows.length} items?`);
    if (confirmDelete) {
      setData((prev) => prev.filter((item) => !selectedRows.includes(item[idKey])));
      setSelectedRows([]);
    }
  };

  return {
    selectedRows,
    isSelected,
    toggleSelectRow,
    toggleSelectAll,
    bulkDelete,
  };
};

export default useRowSelection;
