import React, { useState } from 'react';
import styled from 'styled-components';

const SidebarWrapper = styled.div`
  width: 200px;
  background: #f4f4f4;
  height: 100vh;
  padding: 1rem;
  box-sizing: border-box;
  overflow-y: auto;
`;

const SidebarItem = styled.div`
  margin: 0.25rem 0;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 4px;
  &:hover {
    background: #ddd;
  }
`;

export const GroupTitle = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  padding: 0.5rem;
  background-color: #f5f5f5;
  font-weight: bold;
  color: #333;

  .toggle-icon {
    font-size: 1.2rem;
    margin-left: 1rem;
  }
`;


const Sidebar = ({ onSelect, data }) => {
    const listKeys = Object.keys(data);

    const toggleGroup = (group) => {
        setExpandedGroups((prev) => ({
          ...prev,
          [group]: !prev[group],
        }));
      };
      const [expandedGroups, setExpandedGroups] = useState({});
  return (
    <SidebarWrapper>
      {listKeys?.map(item => (
        <div key={item}>
          <GroupTitle onClick={() => toggleGroup(item)}>
              {item}
              {expandedGroups[item] ? ' −' : ' +'}
              </GroupTitle>
          {expandedGroups[item] && data[item]?.map(tbl => (
            <SidebarItem
              key={tbl}
              onClick={() => onSelect(tbl)}
            >
              {tbl}
            </SidebarItem>
          ))}
        </div>
      ))}
    </SidebarWrapper>
  );
};

export default Sidebar;
