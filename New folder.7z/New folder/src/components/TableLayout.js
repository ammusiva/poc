import React from 'react';
import { FaEdit, FaTrash } from 'react-icons/fa';
import {
  Table,
  Th,
  Td,
  ScrollableTbody,
  ScrollableTr,
} from '../styles/TableViewStyles';

const TableLayout = ({
  columns,
  filteredData,
  openModal,
  handleEdit,
  highlightedRowId,
  uniqueId,
}) => {
  console.log("columns", columns, filteredData);
  return (
    <Table>
      <thead>
        <tr>
          {columns.map((col) => (
            <Th key={col.accessor}>{col.Header}</Th>
          ))}
          <Th>Actions</Th>
        </tr>
      </thead>

      <ScrollableTbody>
        {filteredData.length < 1 ? (
          <ScrollableTr>
            <Td colSpan={columns.length + 2} style={{ textAlign: 'center', padding: '1rem' }}>
              No data found
            </Td>
          </ScrollableTr>
        ) : (
          filteredData.map((item, idx) => (
            <ScrollableTr
              key={idx}
              isHighlighted={highlightedRowId === item[uniqueId]}
            >
              {columns.map((col) => (
                <Td key={col.accessor}>{item[col.accessor]}</Td>
              ))}
              <Td>
                <FaEdit
                  onClick={() => handleEdit(item)}
                  style={{
                    cursor: 'pointer',
                    marginRight: '10px',
                    opacity: 1,
                  }}
                />
                <FaTrash
                  style={{
                    cursor: 'pointer',
                    opacity: 1,
                  }}
                  onClick={
                    () => openModal(item[uniqueId])
                  }
                />
              </Td>
            </ScrollableTr>
          ))
        )}
      </ScrollableTbody>
    </Table>
  );
};

export default TableLayout;
