import React, { useState } from 'react';
import styled from 'styled-components';

const ModalBackdrop = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 1000;
`;

const ModalContainer = styled.div`
  background-color: #fff;
  padding: 2rem;
  border-radius: 8px;
  width: 500px;
  max-height: 90vh;
  overflow-y: auto;
`;

const ModalButton = styled.button`
  padding: 0.5rem 1rem;
  margin: 0.5rem;
  border: none;
  cursor: pointer;
  border-radius: 4px;
  background-color: ${(props) => (props.add ? '#27ae60' : '#7f8c8d')};
  color: white;

  &:hover {
    opacity: 0.85;
  }
`;

const Input = styled.input`
  display: block;
  width: 100%;
  margin-bottom: 1rem;
  padding: 0.5rem;
  border-radius: 4px;
  border: 1px solid #ccc;
`;

const Label = styled.label`
  font-weight: bold;
  margin-bottom: 0.25rem;
  display: block;
`;

const ItemModal = ({ field1s = [], onCancel, onSuccess }) => {
  const fields=['name', 'email', 'dob', 'status'];
  const initialFormState = fields.reduce((acc, field) => {
    acc[field] = '';
    return acc;
  }, {});

  const [formData, setFormData] = useState(initialFormState);

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSubmit = async () => {
    // try {
    //   const response = await fetch('/api/your-endpoint', {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify(formData)
    //   });

    //   if (response.ok) {
    //     const result = await response.json();
    //     onSuccess?.(result);
    //   } else {
    //     console.error('Error creating item');
    //   }
    // } catch (err) {
    //   console.error('API error:', err);
    // }
  };

  return (
    <ModalBackdrop>
      <ModalContainer>
        <h3>Create New Item</h3>
        {fields.map((field, index) => (
          <div key={index}>
            <Label>{field}</Label>
            <Input
              name={field}
              value={formData[field]}
              onChange={handleChange}
              placeholder={`Enter ${field}`}
            />
          </div>
        ))}
        <div>
          <ModalButton add onClick={handleSubmit}>Create</ModalButton>
          <ModalButton onClick={onCancel}>Cancel</ModalButton>
        </div>
      </ModalContainer>
    </ModalBackdrop>
  );
};

export default ItemModal;
