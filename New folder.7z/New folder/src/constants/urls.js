export const BASE_URL = "http://localhost:3001/";
export const GET_TABLES_LIST_URL = "fetchtableslist"