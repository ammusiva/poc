import styled from 'styled-components';
export const TableContainer = styled.div`
  padding: 1rem;
  background-color: white;
  border-radius: 8px;
`;

export const Header = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
`;

export const LeftControls = styled.div`
  display: flex;
  align-items: center;
  gap: 1rem;
`;

export const RightControls = styled.div`
  display: flex;
  align-items: center;
`;

export const FilterInput = styled.input`
  padding: 0.5rem;
  width: 200px;
`;

export const ScrollableTbody = styled.tbody`
  display: block;
  max-height: 300px;
  overflow-y: auto;
`;

export const ScrollableTr = styled.tr`
  display: table;
  width: 100%;
  table-layout: fixed;
  background-color: ${({ isHighlighted }) => (isHighlighted ? '#d0ebff' : 'white')};
  &:nth-child(even) {
    background-color: ${({ isHighlighted }) =>
      isHighlighted ? '#d0ebff' : '#f5faff'};
  }

  transition: background-color 0.3s;
`;

export const Table = styled.table`
  width: 100%;
  border-collapse: collapse;

  thead, tbody tr {
    display: table;
    width: 100%;
    table-layout: fixed;
   
  }

  thead {
    background: #f0f0f0;
  }
  tbody tr td {
    &:first-child {
        width: 20px; /* Adjust the width to fit the checkbox */
      }
  }
`;

export const Th = styled.th`
  padding: 0.5rem;
  background: #f0f0f0;
  &:first-child {
    width: 20px; /* Adjust the width to fit the checkbox */
  }
`;

export const Td = styled.td`
  padding: 0.5rem;
  border-top: 1px solid #ccc;
  text-align: center;
`;
