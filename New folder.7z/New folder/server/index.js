// server/index.js
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 3001;

const mockDatabase = {
    claimflow_rules: [
      { ruleId: "3", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
        { ruleId: "4", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
        { ruleId: "7", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
        { ruleId: "6", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
        { ruleId: "5", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
        { ruleId: "4", submitterId: '38', claimType: 'OP',
        billTypeCode: "ANY", placeOfService: "", groupOnlyIndicator:"N",
        flowRule:"CPS",status:"A", creationDate: 172330800000831,
        updatedBy:"nkumarp", updatedOn: 172330800000831, fromDos: [2024, 8, 29],
        toDos: [2024, 8, 29], effectiveDate: [2024, 8, 29], terminationDate: [2024, 8, 29]},
    ],
    payr_id_over_tbl: [{
        provId: '000054433', payrId: "05040007", ovrdPayrId:"05040007D", 
        faclId: "111", effDt: [2024, 8, 29], cancDt: [2024, 8, 29], stsCd:"A",
        lstUpdateUserId:"nkumarp", lstUpdtDttm: "2018-11-04T15:29:09",
    },
    {
        provId: '000054432', payrId: "05040007", ovrdPayrId:"05040007D", 
        faclId: "111", effDt: [2024, 8, 29], cancDt: [2024, 8, 29], stsCd:"A",
        lstUpdateUserId:"nkumarp", lstUpdtDttm: "2018-11-04T15:29:09",
    },
    {
        provId: '000054431', payrId: "05040007", ovrdPayrId:"05040007D", 
        faclId: "111", effDt: [2024, 8, 29], cancDt: [2024, 8, 29], stsCd:"A",
        lstUpdateUserId:"nkumarp", lstUpdtDttm: "2018-11-04T15:29:09",
    }
    ],
    enrp_incl_xcls_tbl: [
        { id: 1, name: 'Alice', status: 'active' },
        { id: 2, name: 'Bob', status: 'inactive' },
      ],
      mnrp_incl_xcls_tbl: [
        { id: 1, name: 'Laptop', status: 'available' },
        { id: 2, name: 'Phone', status: 'out of stock' },
      ],
      ggmap_edt_rtn_cd_tbl: [
        { id: 1, name: 'Alice', status: 'active' },
        { id: 2, name: 'Bob', status: 'inactive' },
      ],
      ezg_rtn_cd_tbl: [
        { id: 1, name: 'Laptop', status: 'available' },
        { id: 2, name: 'Phone', status: 'out of stock' },
      ],
  };

app.use(cors());
app.use(express.json());

app.get('/api/data', (req, res) => {
  res.json({ message: 'Hello from Node.js API!' });
});

app.get('/fetchtableslist', (req, res) => {
    const tableslist = [];
    res.json({data: {"ggmap":["payr_id_over_tbl", "enrp_incl_xcls_tbl", "mnrp_incl_xcls_tbl","ggmap_edt_rtn_cd_tbl", "ezg_rtn_cd_tbl"], 
    "epp": ["claimflow_rules"]}, status: 'success'})
})
app.get('/getAllRecords',(req, res) => {
    const { tableName } = req.query;

    if (!tableName || !mockDatabase[tableName]) {
      return res.status(400).json({ error: 'Invalid or missing table name' });
    }
  
    const records = mockDatabase[tableName];
    res.json(records);
})

app.get('/deleteRecord',(req, res) => {
    const { tableName, id } = req.query;

    if (!tableName || !mockDatabase[tableName] || !id) {
      return res.status(400).json({ error: 'Invalid or missing table name' });
    }
  
    res.json({ message: 'Record Deleted successfully' });
})

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
