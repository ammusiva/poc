// src/constants/listItems.js

export const listGroups = [
    {
      groupName: 'Test 1',
      items: [
        {
          id: 1,
          name: 'Users',
          columns: [
            { Header: 'ID', accessor: 'id' },
            { Header: 'Name', accessor: 'name' },
            { Header: 'Email', accessor: 'email' }
          ]
        },
        {
          id: 2,
          name: 'Products',
          columns: [
            { Header: 'ID', accessor: 'id' },
            { Header: 'Title', accessor: 'title' },
            { Header: 'Price', accessor: 'price' }
          ]
        }
      ]
    },
    {
      groupName: 'Test 2',
      items: [
        {
          id: 3,
          name: 'Orders',
          columns: [
            { Header: 'Order ID', accessor: 'orderId' },
            { Header: 'Customer', accessor: 'customer' },
            { Header: 'Status', accessor: 'status' }
          ]
        },
        {
          id: 4,
          name: 'Invoices',
          columns: [
            { Header: 'Invoice #', accessor: 'invoiceNo' },
            { Header: 'Date', accessor: 'date' },
            { Header: 'Amount', accessor: 'amount' }
          ]
        }
      ]
    }
  ];
  