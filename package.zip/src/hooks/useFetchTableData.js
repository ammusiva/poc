import { useEffect, useState } from 'react';
import axios from 'axios';
const columns = [
    { "Header": "ID", "accessor": "id" },
    { "Header": "Name", "accessor": "name" },
    { "Header": "Status", "accessor": "status" }
  ];
  const items = [
    { "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },{ "id": 1, "name": "John", "status": "Active" },
    { "id": 2, "name": "Jane", "status": "Inactive" },
  ];
const useFetchTableData = (itemIndex) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  
  useEffect(() => {
    if (itemIndex === null) return;

    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        // const response = await axios.get(`http://localhost:3001/data/${itemIndex}`);
        // setData(response.data.items || []);
        setData(items);
      } catch (err) {
        setError('Failed to fetch data');
        setData([]);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [itemIndex]);

  return { data, loading, error, columns };
};

export default useFetchTableData;
