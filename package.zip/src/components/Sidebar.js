import React from 'react';
import styled from 'styled-components';
import { listGroups } from '../constants/listItems';

const SidebarWrapper = styled.div`
  width: 200px;
  background: #f4f4f4;
  height: 100vh;
  padding: 1rem;
  box-sizing: border-box;
  overflow-y: auto;
`;

const GroupTitle = styled.h4`
  margin-top: 1rem;
  margin-bottom: 0.5rem;
  font-size: 1rem;
  color: #333;
`;

const SidebarItem = styled.div`
  margin: 0.25rem 0;
  cursor: pointer;
  padding: 0.5rem;
  border-radius: 4px;
  &:hover {
    background: #ddd;
  }
`;

const Sidebar = ({ onSelect }) => {
  return (
    <SidebarWrapper>
      {listGroups.map((group, groupIdx) => (
        <div key={group.groupName}>
          <GroupTitle>{group.groupName}</GroupTitle>
          {group.items.map((item, itemIdx) => (
            <SidebarItem
              key={item.id}
              onClick={() => onSelect(item)}
            >
              {item.name}
            </SidebarItem>
          ))}
        </div>
      ))}
    </SidebarWrapper>
  );
};

export default Sidebar;
