import React from 'react';
import styled from 'styled-components';

const HeaderWrapper = styled.div`
  background-color: #282c34;
  color: white;
  padding: 1rem;
`;

const Header = () => {
  return <HeaderWrapper>My Application</HeaderWrapper>;
};

export default Header;
