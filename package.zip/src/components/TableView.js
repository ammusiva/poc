import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { FaEdit, FaTrash } from 'react-icons/fa';
import useFetchTableData from '../hooks/useFetchTableData';
import useRowSelection from '../hooks/useRowSelection';

const TableContainer = styled.div`
  padding: 1rem;
  background-color: white;
  border-radius: 8px;
`;

const Header = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 1rem;
`;

const FilterInput = styled.input`
  padding: 0.5rem;
  width: 200px;
`;

const ScrollableTbody = styled.tbody`
  display: block;
  max-height: 300px;
  overflow-y: auto;
`;

const ScrollableTr = styled.tr`
  display: table;
  width: 100%;
  table-layout: fixed;
`;

const Table = styled.table`
  width: 100%;
  border-collapse: collapse;

  thead, tbody tr {
    display: table;
    width: 100%;
    table-layout: fixed;
  }

  thead {
    background: #f0f0f0;
  }
`;

const Th = styled.th`
  padding: 0.5rem;
  background: #f0f0f0;
`;

const Td = styled.td`
  padding: 0.5rem;
  border-top: 1px solid #ccc;
`;

const TableView = ({ item }) => {
    console.log("item is", item);
    const { columns, data, loading, error } = useFetchTableData(item.id);
    const {
        selectedRows,
        isSelected,
        toggleSelectRow,
        toggleSelectAll,
        bulkDelete,
      } = useRowSelection(data, 'id');
    const [filter, setFilter] = useState('');

    const filteredData = data.filter((row) =>
        Object.values(row).some((value) =>
            String(value).toLowerCase().includes(filter.toLowerCase())
        )
    );

    return (
        <TableContainer>
            <h2>{item.name}</h2>
            {loading && <p>Loading...</p>}
            {error && <p>{error}</p>}
            {!loading && !error && (
                <>
                    <Header>
                        <button>Add</button>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                            <FilterInput
                                type="text"
                                placeholder="Filter..."
                                value={filter}
                                onChange={(e) => setFilter(e.target.value)}
                            />
                           {selectedRows.length > 1 && (
  <button >Delete</button>
)}
                        </div>
                    </Header>
                    <Table>
                        <thead>
                            <tr>
                            <Th>
  <input
    type="checkbox"
    checked={selectedRows.length === data.length}
    onChange={toggleSelectAll}
  />
</Th>
                                {columns.map((col) => (
                                    <Th key={col.accessor}>{col.Header}</Th>
                                ))}
                                <Th>Actions</Th>
                            </tr>
                        </thead>
                        <ScrollableTbody>
                            {filteredData.length < 1 ? (
                                <ScrollableTr>
                                    <Td colSpan={columns.length + 2} style={{ textAlign: 'center', padding: '1rem' }}>
                                        No data found
                                    </Td>
                                </ScrollableTr>
                            ) : (
                                filteredData.map((item, idx) => (
                                    <ScrollableTr key={idx}>
                                        <Td><input type="checkbox"
                                        checked={isSelected(item.id)}
                                        onChange={() => toggleSelectRow(item.id)} /></Td>
                                        {columns.map((col) => (
                                            <Td key={col.accessor}>{item[col.accessor]}</Td>
                                        ))}
                                        <Td>
                                            <FaEdit style={{ cursor: 'pointer', marginRight: '10px' }} />
                                            <FaTrash style={{ cursor: 'pointer' }} />
                                        </Td>
                                    </ScrollableTr>
                                ))
                            )}
                        </ScrollableTbody>
                    </Table>
                </>
            )}
        </TableContainer>
    );
};

export default TableView;
